import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Link} from "react-router-dom";

//Show  employee details
export default function EmpDetail() {
  const { empid } = useParams();
  const [empdata, empdatachange] = useState({});
  useEffect(() => {
    fetch("http://localhost:8001/employee/" + empid)
      .then((res) => {
        return res.json();
      })
      .then((resp) => {
        empdatachange(resp);
      })
      .catch((err) => {
        console.log(err.message);
      });
  }, []);

  return (
    <div>
      <div className="card outer" style={{ textAlign: "center" }}>
        <div className="card-title">
        </div>{" "}
        {empdata && (
          <h1>
            <h1>Employee Details</h1>
            <h5>The Employee name is : {empdata.name}</h5>
            <h5>Employee id is: {empdata.id}</h5>
            <h5>Email is: {empdata.email}</h5>
            <h5>Phone is: {empdata.phone}</h5>
            <Link className="btn btn-danger" to="/">Back to Listing</Link>
          </h1>
        )}
      </div>
    </div>
  );
}
