import React from "react";
import { Formik, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { Link, useNavigate } from "react-router-dom";

//Create new employee record
const EmpCreate = () => {
  const navigate = useNavigate();

  //validation function
  const validationSchema = Yup.object().shape({
    name: Yup.string()
      .required("Name is required")
      .matches(/(?=.*[',A-Z,a-z])/, "Name must contain letter.")
      .min(2, "Too Short!")
      .max(25, "Too Long!"),
    email: Yup.string()
      .email("Please enter valid email")
      .matches(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)
      .required("Email is required"),
    phone: Yup.string()
      .required("phone required")
      .matches(/^\d{10}$/, "Mobile number must be 10 digits"),
  });

  return (
    <div>
      <div className="row">
        <div className="offset-lg-3 col-lg-6">
          {/* //formik used for validations */}
          <Formik
            initialValues={{
              id: "",
              name: "",
              email: "",
              phone: "",
              active: true,
            }}
            enableReinitialize
            validationSchema={validationSchema}
            onSubmit={(values) => {
              fetch("http://localhost:8001/employee", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(values),
              })
                .then((res) => {
                  alert("Saved successfully.");
                  navigate("/");
                })
                .catch((err) => {
                  console.error(err.message);
                });
            }}
          >
            {({
              values,
              handleChange,
              handleBlur,
              handleSubmit,
              errors,
              touched,
            }) => (
              <form className="container  outer" onSubmit={handleSubmit}>
                <div className="card" style={{ textAlign: "left" }}>
                  <div className="card-title">
                    <h2>Employee Create</h2>
                  </div>
                  <div className="card-body">
                    <div className="row">
                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>ID</label>
                          <Field
                            type="text"
                            name="id"
                            value={values.id}
                            className="form-control"
                            disabled
                          />
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Name</label>
                          <Field
                            type="text"
                            name="name"
                            value={values.name}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            className={`form-control ${
                              errors.name && touched.name ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            name="name"
                            component="div"
                            className="text-danger"
                          />
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Email</label>
                          <Field
                            type="email"
                            name="email"
                            value={values.email}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            className={`form-control ${
                              errors.email && touched.email ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            name="email"
                            component="div"
                            className="text-danger"
                          />
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Phone</label>
                          <Field
                            type="text"
                            name="phone"
                            value={values.phone}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            className={`form-control ${
                              errors.phone && touched.phone ? "is-invalid" : ""
                            }`}
                          />
                          <ErrorMessage
                            name="phone"
                            component="div"
                            className="text-danger"
                          />
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-check">
                          <Field
                            type="checkbox"
                            name="active"
                            checked={values.active}
                            className="form-check-input"
                          />
                          <label className="form-check-label">Is Active</label>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <button className="btn btn-success" type="submit">
                            Save
                          </button>
                          <Link to="/" className="btn btn-danger">
                            Back
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
};

export default EmpCreate;
