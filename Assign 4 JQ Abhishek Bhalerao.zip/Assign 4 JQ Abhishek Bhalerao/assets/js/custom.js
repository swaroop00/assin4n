jQuery(document).ready(function($) {

  let grandTotal = 0
  $("#calculate").on('click',function(){
    $("#total-amount").hide();
    console.log($(".row-array").length-1);
    let quantity = $(".row-array").eq($(".row-array").length-1).children().eq(1).children();
    let price = $(".row-array").eq($(".row-array").length-1).children().eq(2).children();
    let total = $(".row-array").eq($(".row-array").length-1).children().eq(3).children();
    let parsedQuantity = parseFloat(quantity.val());
    let parsedPrice = parseFloat(price.val());
    total.val(parsedQuantity * parsedPrice);
    grandTotal += parseFloat(total.val());
  })
  
  let newRow = $("#add-row").html();
  $("#add-more").on('click',function(){
    $("#total-amount").hide();
    let total = $(".row-array").eq($(".row-array").length-1).children().eq(3).children();
    console.log(total.val());
    if(total.val() == ""){
      alert("please calculate the total of the row first");
    }else{
      $("#cal-control").before("<div class='row form-group row-array'>" + newRow + "</div>");
    }
    // grandTotal = $("#total-amount").html();
  })

  $('#show-total').on('click',function(){
    $("#total-amount").show();
    $("#total-amount").text("The grand total is " + grandTotal);
  })


});
  
	 

