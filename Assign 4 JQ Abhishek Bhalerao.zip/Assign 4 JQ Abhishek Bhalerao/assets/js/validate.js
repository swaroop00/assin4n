$(document).ready(function(){

  jQuery.validator.addMethod("lettersonly", function(value, element) {
    return this.optional(element) || /^[a-z ]+$/i.test(value);
  }, "Letters and space only please");

  $("#main-form").validate({
    rules:{
      productname:{
        required:true,
        lettersonly:true,
        minlength:2
      },
      quantity:{
        required:true,
        digits:true,
        maxlength:2,
      },
      price:{
        required:true,
        maxlength:5,
      },
    },
    messages:{
      productname:{
        required:"enter a product name",
        lettersonly:"enter valid product name",
        minlength:"enter valid product name"
      },
      quantity:{
        required:"enter a quantity",
        maxlength:"more than 99 is not valid"
      },
      price:{
        required:"enter a price",
        maxlength:"Enter a valid price"
      }
    }
  })

})