import '../Footer.css'
import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <footer className="main-footer clearfix fixed-bottom">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <p>Copyright &copy; {new Date().getFullYear()} react</p>
            </div>
          </div>
        </div>
      </footer>
    )
  }
}
