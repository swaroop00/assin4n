import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'

/*function is used to 
view user data and validation of user*/

const EmpDetail = () => {
  const { empid } = useParams();

  const [empdata, empdatachange] = useState({});

  /* use to fetch data
   to json 
   server */
  useEffect(() => {
    fetch("http://localhost:8000/employee/" + empid).then((response) => {
      return response.json();
    }).then((response) => {
      empdatachange(response);
    }).catch((error) => {
      console.log(error.message);
    })
  }, []);

  return (
    <div>
      <div className="card row" style={{ "textAlign": "left" }}>
        <div className="card-title">
          <h2>Employee Create</h2>
        </div>
        <div className="card-body"></div>

        {empdata &&
          <div>
            <h2>The employee name is: <b>{empdata.name}</b> ({empdata.id})</h2>
            <h3>More Details</h3>
            <h5>Email is: {empdata.email}</h5>
            <h5>Contact is: {empdata.contact}</h5>
            <Link className="btn btn-danger" to="/">Back to Listing</Link>
          </div>
        }
      </div>
    </div>
  );
}

export default EmpDetail