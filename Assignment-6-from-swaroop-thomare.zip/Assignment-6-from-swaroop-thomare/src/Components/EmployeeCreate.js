import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Formik, Form, Field } from 'formik';
import { object, string } from 'yup';
// import '../App.css';

const initialValues = {
  name: '',
  email: '',
  contact: ''
}

const CreateEmployee = () => {

  const [id, idchange] = useState("");
  const [active, activechange] = useState(true);


  const navigate = useNavigate();

  //const variable
  const phoneRegExp = /^[0-9]{10}$/;

  const validationSchema = object({
    name: string().required().min(3).max(30),
    email: string().required('Email is required').matches(/^\S+@\S+\.\S+$/, 'Invalid Email'),
    contact: string().matches(phoneRegExp, 'phone number is not valid').required('Phone number is required')
  });


  const handleSubmit = (values) => {

    fetch("http://localhost:8000/employee", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(values)
    }).then((res) => {
      alert('Saved successfully.')
      navigate('/');
    }).catch((err) => {

    })
  }

  return (
    <div>
      <div className="row">
        <div className="offset-lg-3 col-lg-6">
          <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
            {({ values, errors }) => (
              <Form className="container">

                <div className="card" style={{ "textAlign": "left" }}>
                  <div className="card-title">
                    <h2>Employee Create</h2>
                  </div>
                  <div className="card-body">

                    <div className="row">

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>ID</label>
                          <input value={id} disabled="disabled" className="form-control"></input>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label htmlFor="name">Name</label>
                          <Field type="text" id="name" name='name' className="form-control" />
                          <p className="err">{errors.name}</p>

                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label htmlFor="email">Email</label>
                          <Field type="email" id="email" name='email' className="form-control" />
                          <p className="err">{errors.email}</p>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label htmlFor="contact">contact</label>
                          <Field type="string" id="contact" name='contact' className="form-control" />
                          <p className="err">{errors.contact}</p>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <button className="btn btn-success" type="submit">Save</button>
                          <Link to="/" className="btn btn-danger">Back</Link>
                        </div>
                      </div>

                    </div>

                  </div>

                </div>

              </Form>
            )}
          </Formik>

        </div>
      </div>
    </div>
  );
}

export default CreateEmployee;