import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './App.css';
import Employee from './Components/Employee';
import EmpDetail from './Components/EmployeeDetail';
import EmpEdit from './Components/EmployeeEdit';
import CreateEmployee from './Components/EmployeeCreate'
import Footer from './Components/Footer';
import Navbar from './Components/Navbar';

function App() {
  return (
    <div>
      <Navbar />
      <div className="App">
        <h1>CRUD Operation</h1>

        <BrowserRouter>
          <Routes>
            <Route path='/' element={<Employee />}></Route>
            <Route path='/employee/create' element={<CreateEmployee />}></Route>
            <Route path='/empdetail/detail/:empid' element={<EmpDetail />}></Route>
            <Route path='/empedit/edit/:empid' element={<EmpEdit />}></Route>
          </Routes>
        </BrowserRouter>
      </div>
      <Footer />
    </div>
  );

}

export default App;
